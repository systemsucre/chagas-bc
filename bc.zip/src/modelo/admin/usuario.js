const pool = require('../bdConfig.js')

module.exports = class Usuario {
  // METODOS



  // metodos publicos

  listarMedicos = async () => {

    const sql1 = `SELECT e.entidad, e.direccion, e.celular,  m.img as img, m.medico , m.rol
            from medico m
            inner join rol r on r.id = m.rol
            inner join entidad e on e.id = m.entidad
            where r.id > 2`;
    const [rows1] = await pool.query(sql1);

    const sql2 = `SELECT *
    from compañia`;
    const [rows2] = await pool.query(sql2);

    const sql4 = `SELECT p.id, p.categoria as idcategoria, p.producto, p.id as img, p.beneficios, p.estado, c.id as categoria, c.categoria as nombrecategoria,  c.color2,c.color3
    from productos p
    inner join categorias c on p.categoria = c.id
    where p.estado!=0 order by p.producto DESC limit 8`;
    const [rows4] = await pool.query(sql4);

    const sql5 = `SELECT *
    from categorias`;
    const [rows5] = await pool.query(sql5);

    return [rows1, rows2, rows4, rows5];
  };


  // metodos admin
  listar = async (id, cantidad) => {
    const sql = `SELECT 
    m.id, m.ci, r.id as idrol, r.rol, m.medico, es.id as  idespecialidad, es.especialidad,e.id as identidad,
            e.entidad, m.celular, m.correo, m.estado
            from medico m 
            left join rol r on r.id = m.rol
            left join entidad e on e.id = m.entidad
            left join especialidad es on es.id = m.especialidad
            where m.id != ${pool.escape(id)}
            ORDER by m.id desc limit ${pool.escape(cantidad)}`;

    const [rows] = await pool.query(sql);
    const cant = `SELECT count(id) as cantidad from medico
            where id != ${pool.escape(id)}
            `;
    const [cat1] = await pool.query(cant);
    return [rows, cat1[0].cantidad];
  };
  listarExcel = async () => {
    const sql = `SELECT 
            m.id, m.ci, r.id as idrol, r.rol, m.medico, es.id as  idespecialidad, es.especialidad,e.id as identidad,m.creating, m.editing,m.acceso, me.medico as autor,
            e.entidad, m.celular, m.correo, m.estado
            from medico m 
            left join rol r on r.id = m.rol
            left join entidad e on e.id = m.entidad
            left join especialidad es on es.id = m.especialidad
            inner join medico me on me.id =  m.usuario
            `;

    const [rows] = await pool.query(sql);

    return rows
  };

  listarEntidad = async () => {
    const sql = `SELECT id, entidad as label from entidad  where estado = 1 order by entidad asc`;
    const [rows] = await pool.query(sql);
    const sql1 = `SELECT id, rol as label from rol `;
    const [rows1] = await pool.query(sql1);

    const sql2 = `SELECT id, especialidad as label from especialidad `;
    const [rows2] = await pool.query(sql2);
    // console.log(rows, "oficinaaa ");
    return [rows, rows1, rows2];
  };

  buscar = async (dato, user) => {
    // console.log('los datos han llegado', dato)
    const sql = `SELECT 
            m.id, m.ci, r.id as idrol, r.rol, m.medico, es.id as  idespecialidad, es.especialidad,e.id as identidad,
            e.entidad, m.celular, m.correo, m.estado
            from medico m 
            left join rol r on r.id = m.rol
            left join entidad e on e.id = m.entidad
            left join especialidad es on es.id = m.especialidad
            where (m.medico like '${dato}%' or
            m.ci like '${dato}%') and m.id != ${pool.escape(user)}
            ORDER by m.id asc`;
    const [rows] = await pool.query(sql);
    return rows;
  };

  listarSiguiente = async (id, user, cantidad) => {
    const sql = `SELECT 
            m.id, m.ci, r.id as idrol, r.rol, m.medico, es.id as  idespecialidad, es.especialidad,e.id as identidad,
            e.entidad, m.celular, m.correo, m.estado
            from medico m 
            left join rol r on r.id = m.rol
            left join entidad e on e.id = m.entidad
            left join especialidad es on es.id = m.especialidad
            where m.id != ${pool.escape(user)}
            and m.id < ${pool.escape(id)} ORDER by m.id DESC  limit ${pool.escape(cantidad)}`;
    const [rows] = await pool.query(sql);
    // console.log("los datos han llegado", sql);
    return rows;
  };
  listarAnterior = async (id, user, cantidad) => {
    const sql = `SELECT 
            m.id, m.ci, r.id as idrol, r.rol, m.medico, es.id as  idespecialidad, es.especialidad,e.id as identidad,
            e.entidad, m.celular, m.correo, m.estado
            from medico m 
            left join rol r on r.id = m.rol
            left join entidad e on e.id = m.entidad
            left join especialidad es on es.id = m.especialidad
            WHERE m.id > ${pool.escape(id)} and m.id != ${pool.escape(user)} 
            limit ${pool.escape(cantidad)}`;
    const [rows] = await pool.query(sql);
    rows.reverse();
    return rows;
  };

  insertar = async (datos, cantidad) => {

    const sqlexisteC = `SELECT correo from medico where
                correo = ${pool.escape(
      datos.correo
    )} and correo != 'example@systemsucre.info'`;
    const [rowsCorreo] = await pool.query(sqlexisteC);

    if (rowsCorreo.length === 0) {
      const sqlci = `SELECT ci from medico where
                    ci = ${pool.escape(datos.ci)}`;
      const [rows] = await pool.query(sqlci);

      if (rows.length === 0) {

        await pool.query("INSERT INTO medico SET  ?", datos);
        return await this.listar(datos.usuario, cantidad);
      } else return { error: 3 };
    } else return { error: 2 };
  };

  actualizar = async (datos) => {
    // console.log(datos, "datos desde el modelo");
    const sqlcorreo = `SELECT correo from medico where
                correo = ${pool.escape(datos.correo)} and id != ${pool.escape(datos.id)} and correo != 'example@systemsucre.info'`;
    const [rowsCorreo] = await pool.query(sqlcorreo);

    if (rowsCorreo.length === 0) {
      const sqlci = `SELECT ci from medico where
        ci = ${pool.escape(datos.ci)} and id != ${pool.escape(datos.id)}`;
      const [rows] = await pool.query(sqlci);

      if (rows.length === 0) {
        const sql = `UPDATE medico SET
                rol = ${pool.escape(datos.rol)},
                
                ci = ${pool.escape(datos.ci)},
                medico = ${pool.escape(datos.medico)},
               
                celular = ${pool.escape(datos.celular)},
                correo = ${pool.escape(datos.correo)},

                entidad = ${pool.escape(datos.entidad)},
                especialidad = ${pool.escape(datos.especialidad)},

                estado=${pool.escape(datos.estado)},
                editing = ${pool.escape(datos.fecha_)},
                usuario = ${pool.escape(datos.usuario)}
                WHERE id = ${pool.escape(datos.id)}`;

        const [res] = await pool.query(sql);

        if (res.affectedRows > 0) {
          const sesion = `delete from sesion where
          usuario = ${pool.escape(datos.id)}`;
          await pool.query(sesion);
          return await this.listar(datos.usuario, datos.cantidad)
        }
        else return { error: 1 }

      } else return { existe: 3 };
    } else return { existe: 2 };
  };






  miPerfil = async (id, hospital) => {
    let sqlUser = `select * 
                            from usuario
                            where id  = ${pool.escape(id)}`;
    const [result] = await pool.query(sqlUser);

    let sqlUsuarios = `select u.id, concat(u.nombre,' ', u.ap1, ' ', u.ap2) as nombre,h.nombre as hospital, u.estado, r.rol, 
    DATE_FORMAT(u.creating, "%y/%M/%d" ) as creacion
                        from usuario u
                        inner join rol r on r.id = u.rol
                        inner join hospital h  on h.id = u.hospital
                        where h.id  = ${pool.escape(hospital)} and u.id != ${pool.escape(id)}`;

    const [resultOtrosUsuario] = await pool.query(sqlUsuarios);

    return [result, resultOtrosUsuario];
  };


  // metodos, gestionar mi perfil
  cambiarMiContraseña = async (datos) => {
    const sqlExists = `SELECT * FROM usuario WHERE 
            contraseña = ${pool.escape(datos.contraseña_actual)} 
            and id = ${pool.escape(datos.user)}`;
    const [result] = await pool.query(sqlExists);

    if (result.length > 0) {
      const sql = `UPDATE usuario SET
                contraseña = ${pool.escape(datos.nueva_contraseña)}, modified = ${pool.escape(datos.modified)}, user_modified = ${pool.escape(datos.user)}
                WHERE id = ${pool.escape(datos.user)}`;

      await pool.query(sql);
      return true;
    } else return false;
  };

  actualizarMiPerfil = async (datos) => {
    const sqlexisteCorreo = `SELECT correo from usuario where correo = ${pool.escape(datos.correo)} and id != ${pool.escape(datos.user_modified)}`;
    const [result] = await pool.query(sqlexisteCorreo);
    if (result.length === 0) {
      const sql = `UPDATE usuario SET
            nombre = ${pool.escape(datos.nombre)},
            ap1 = ${pool.escape(datos.ap1)},
            ap2 = ${pool.escape(datos.ap2)},
            celular = ${pool.escape(datos.celular)},
            correo = ${pool.escape(datos.correo)},
            direccion = ${pool.escape(datos.direccion)},
            modified = ${pool.escape(datos.modified)},
            user_modified = ${pool.escape(datos.user_modified)}
            WHERE id = ${pool.escape(datos.user_modified)}`;
      const result = await pool.query(sql);
      if (result[0].affectedRows > 0) return true
      else return false
    } else return { existe: -1 };
  };





  recet = async (datos) => {
    const sql = `UPDATE medico SET
                contraseña = ${pool.escape(datos.otros)},
                usuario = ${pool.escape(datos.usuario)},
                editing = ${pool.escape(datos.fecha_)}
                WHERE id = ${pool.escape(datos.id)}`;
    const [res] = await pool.query(sql);
    if (res.affectedRows > 0) {
      const sesion = `delete from sesion where
                    usuario = ${pool.escape(datos.id)}`;
      await pool.query(sesion);
      return true;
    }
  };




}
