
const pool = require('../../bdConfig.js')

module.exports = class Rociado {


    mostrarAvance = async (municipio) => {
        const sql = `select if(u.ap2,concat(u.nombre, ' ', u.ap1, ' ',u.ap2), concat(u.nombre, ' ', u.ap1))  as tecnico, c.nombre as comunidad, r.estado, count(r.id) as avance, DATE_FORMAT(r.fecha_remision, '%Y/%m/%d') as fecha_remision
                    from rociado r
                    inner join usuario u on u.id = r.usuario 
                    inner join comunidad c on c.id = r.comunidad
                    where r.municipio = ${pool.escape(municipio)}
                    group by r.codigo order by r.id
                    `
        const [rows] = await pool.query(sql)
        return rows
    }

    listar = async (municipio) => {
        const sql =
            `SELECT  r.id, c.id as idcomunidad, c.nombre as comunidad,
                DATE_FORMAT(min(r.fecha), '%Y/%m/%d') as inicio, DATE_FORMAT(max(r.fecha), '%Y/%m/%d') as final, 
                sum(cs.habitantes) as habitantes ,
                c.num_viviendas_actual AS viv_existentes, 
                COUNT(r.id) AS viv_rociadas,
                sum(r.cerrada) as cerrada,
                sum(r.renuente) as renuente,
                sum(r.idr) as idr,
                sum(r.idnr) as idnr,
                count(r.id) as cantidad,
                sum(r.corrales) as corrales,
                sum(r.gallineros) as gallineros,
                sum(r.conejeras) as conejeras,
                sum(r.zarzo) as zarzo,
                sum(r.otros) as otros,
                r.dosis,
                sum(r.numeroCargas) as totalCargas,
                round((sum(r.dosis)/1000), 3) as totalUnidad,
                ci.ciclo,
               DATE_FORMAT(r.fecha_remision, '%Y/%m/%d') AS fecha_remision, 
               DATE_FORMAT(r.fecha_remision_jefeBrigada, '%Y/%m/%d') AS fecha_remision_jefeBrigada, 
               r.estado, r.codigo


                FROM rociado r
                inner join insecticida i on i.id = r.insecticida
                inner join clicor ci on ci.id = r.ciclo
                inner join casa cs on cs.id = r.casa
                inner join comunidad c on c.id = cs.comunidad
                inner join municipio m on m.id = c.municipio
                where m.id = ${pool.escape(municipio)} and r.estado >0
                group by r.codigo
                order by r.id  asc`;
        const [rows] = await pool.query(sql)
        const sqlOtros =
            `SELECT    m.nombre as municipio,  r.nombre as red
                FROM municipio m 
                inner join red r on r.id = m.red
                where m.id = ${pool.escape(municipio)}`
        const [rowsOtros] = await pool.query(sqlOtros)
        const sqlComunidad =
            `SELECT  * from comunidad
            where municipio = ${pool.escape(municipio)}`
        const [rowsComunidad] = await pool.query(sqlComunidad)
        return [rows, rowsOtros, rowsComunidad]
    }


    buscar = async (fecha1, fecha2, municipio) => {
        const sql =
            `SELECT  r.id, c.id as idcomunidad, c.nombre as comunidad,
                DATE_FORMAT(min(r.fecha), '%Y/%m/%d') as inicio, DATE_FORMAT(max(r.fecha), '%Y/%m/%d') as final, 
                sum(cs.habitantes) as habitantes ,
                c.num_viviendas_actual AS viv_existentes, 
                COUNT(r.id) AS viv_rociadas,
                sum(r.cerrada) as cerrada,
                sum(r.renuente) as renuente,
                sum(r.idr) as idr,
                sum(r.idnr) as idnr,
                count(r.id) as cantidad,
                sum(r.corrales) as corrales,
                sum(r.gallineros) as gallineros,
                sum(r.conejeras) as conejeras,
                sum(r.zarzo) as zarzo,
                sum(r.otros) as otros,
                r.dosis,
                sum(r.numeroCargas) as totalCargas,
                round((sum(r.dosis)/1000), 3) as totalUnidad,
                ci.ciclo,
                DATE_FORMAT(r.fecha_remision, '%Y/%m/%d') AS fecha_remision, 
                DATE_FORMAT(r.fecha_remision_jefeBrigada, '%Y/%m/%d') AS fecha_remision_jefeBrigada, 
                r.estado, r.codigo

                FROM rociado r
                inner join insecticida i on i.id = r.insecticida
                inner join clicor ci on ci.id = r.ciclo
                inner join casa cs on cs.id = r.casa
                inner join comunidad c on c.id = cs.comunidad
                inner join municipio m on m.id = c.municipio
                where m.id = ${pool.escape(municipio)} and r.estado >0 and ( r.fecha BETWEEN ${pool.escape(fecha1)} and ${pool.escape(fecha2)}) 
                group by r.codigo
                order by r.id  asc`;
                // console.log(sql)
        const [rows] = await pool.query(sql)
        return rows
    }


    habilitarEdicion = async (codigo) => {

        const sql_ = `update rociado set estado = 0 WHERE codigo = ${pool.escape(codigo)} AND estado = 1 `;
        const result = await pool.query(sql_);
        console.log(result, codigo)
        if (result[0].affectedRows > 0) {
            return true
        } else return false

    }


    validar = async ( fecha, codigo) => {

        const sql_ = `update rociado set estado = 2, fecha_remision_jefeBrigada = ${pool.escape(fecha)}
            WHERE   codigo = ${pool.escape(codigo)} AND estado = 1 `;
        const result = await pool.query(sql_);
        console.log(result, codigo)
        if (result[0].affectedRows > 0) {

            // const sql_comunidad = `select c.id,  count(cs.id) as casas from casa cs inner join comunidad c on c.id = cs.comunidad where c.municipio = ${pool.escape(municipio)} group by c.id `;
            // const [result] = await pool.query(sql_comunidad);
            // console.log(result)
            // for (let r of result) {
            //     const sql_ = `update comunidad set usuario_eval_actual = null, num_viviendas_actual= ${pool.escape(r.casas)} where id = ${pool.escape(r.id)}`; // actualizar el numer de viviendas para la proxima actividad. Este dato servirá para mostrar en el formulario ee2->viviendas->prog
            //     await pool.query(sql_);
            // }
            return true
        } else return false

    }

    
    listarPorComunidad = async (codigo) => {
        const sql =
            `SELECT  r.id, cs.id as idcasa, cs.cv, cs.jefefamilia, cs.habitantes, if(r.cerrada, 'SI', 'NO') AS cerrada, if(r.renuente, 'SI', 'NO') AS renuente, r.cerrada as cerrada_n, r.renuente as renuente_n, 
                r.idr, r.idnr, r.corrales, r.gallineros, r.conejeras, r.zarzo, r.otros, r.numeroCargas, i.unidad,  r.dosis, r.lote, r.estado, DATE_FORMAT(r.fecha,"%Y/%m/%d") AS fecha, 
                r.insecticida, r.ciclo, i.nombre as nombreInsecticida, ci.ciclo as nombreCiclo, r.observaciones, u.id as idUsuarioBrigada, concat(u.nombre, ' ', u.ap1) as usuarioBrigada, concat(us.nombre, ' ', us.ap1) as usuarioAutor, c.nombre as comunidad, h.nombre as hospital, m.nombre as municipio, re.nombre as red
                FROM rociado r
                inner join insecticida i on i.id = r.insecticida
                inner join clicor ci on ci.id = r.ciclo
                inner join casa cs on cs.id = r.casa
                inner join usuario u on u.id = r.usuarioBrigada
                inner join comunidad c on c.id = cs.comunidad
                inner join hospital h on h.id = c.est
                inner join municipio m on m.id = c.municipio
                inner join red re on re.id = m.red
                inner join usuario us on us.id = r.usuario 
                where  r.codigo = ${pool.escape(codigo)}
                order by r.id  desc`;
        const [rows] = await pool.query(sql)
        // console.log(codigo, rows,'parametros listar rociado por comundiad')

        return rows
    }
}
