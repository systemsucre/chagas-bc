
const pool = require('../../bdConfig.js')

module.exports = class EE2 {


    mostrarAvance = async (municipio) => {
        const sql = `select if(u.ap2,concat(u.nombre, ' ', u.ap1, ' ',u.ap2), concat(u.nombre, ' ', u.ap1))  as tecnico, c.nombre as comunidad, e.estado, count(e.id) as avance
                    from ee1 e 
                    inner join usuario u on u.id = e.usuario 
                    inner join comunidad c on c.id = e.comunidad
                    where e.municipio = ${pool.escape(municipio)}
                    group by c.id
                    `
        const [rows] = await pool.query(sql)
        return rows
    }

    listar = async (municipio) => {
        const sql =
            `SELECT  e.id, c.id as idcomunidad, c.nombre as comunidad, max(e.prerociado) as prerociado,
            
                DATE_FORMAT(min(e.fecha), '%Y/%m/%d') as inicio, DATE_FORMAT(max(e.fecha), '%Y/%m/%d') as final, 
                sum(cs.habitantes) as habitantes, 
                sum(cs.num_hab) as num_hab, 
                COUNT(cs.id) AS viv_existentes, 
                c.num_viviendas_actual,
                COUNT(e.disponible) AS disponible,
                round(((COUNT(e.disponible)/COUNT(cs.id))*100), 2) as cob,

                (select count(id) from ee1 where (ecin+  ecia+ecpn+ ecpa) >0  and comunidad = c.id and estado = 1)  as viv_pos,
                (select count(id) from ee1 where (ecin + ecia) >0 and comunidad = c.id and estado = 1 )  as pos_intra,
                (select count(id) from ee1 where (ecpn + ecpa) >0 and  comunidad = c.id and estado = 1 )  as pos_peri,


                (select count(id) from ee1 where (ecin+ ecpn) >0 and  comunidad = c.id and estado = 1)  as pos_ninfas,
                (select count(id) from ee1 where (ecin) >0 and  comunidad = c.id and estado = 1)  as pos_ninfas_intra,
                (select count(id) from ee1 where ecpn >0 and comunidad = c.id and estado = 1)  as pos_ninfas_peri,

                (select count(id) from casa where vm_intra = 1 and comunidad = c.id) as vm_intra_si,
                (select count(id) from casa where vm_intra = 0 and comunidad = c.id) as vm_intra_no,

                (select count(id) from casa where vm_peri = 1 and comunidad = c.id) as vm_peri_si,
                (select count(id) from casa where vm_peri = 0 and comunidad = c.id) as vm_peri_no,
          

                 sum(e.ecin) as ecin,  sum(e.ecia) as ecia, sum(e.ecpn) as ecpn, sum(e.ecpa) as ecpa, 
                 sum(e.lcipd) as lcipd, sum(e.lcicm) as lcicm, sum(e.lcith) as lcith, sum(e. lciot) as lciot , sum(e.lcppd) as lcppd,
                 sum(e.lcpga) as lcpga, sum(e.lcpcl) as lcpcl, sum(e.lcpcj) as lcpcj, sum(e.lcpz) as lcpz, sum(e.lcpot) as lcpot, cs.altitud, cs.latitud, cs.longitud


                FROM ee1 e
                inner join casa cs on cs.id = e.casa
                inner join comunidad c on c.id = cs.comunidad
                inner join municipio m on m.id = c.municipio
                where m.id = ${pool.escape(municipio)} 
                group by c.id
                order by c.id  asc`;
        const [rows] = await pool.query(sql)
        const sqlOtros =
            `SELECT    m.nombre as municipio,  r.nombre as red
                FROM municipio m 
                inner join red r on r.id = m.red
                where m.id = ${pool.escape(municipio)}`
        const [rowsOtros] = await pool.query(sqlOtros)
        const sqlComunidad =
            `SELECT  * from comunidad
            where municipio = ${pool.escape(municipio)}`
        const [rowsComunidad] = await pool.query(sqlComunidad)
        return [rows, rowsOtros, rowsComunidad]
    }


    buscar = async (fecha1, fecha2, municipio) => {
        const sql =
            `SELECT  e.id, c.id as idcomunidad, c.nombre as comunidad, max(e.prerociado) as prerociado,
            
                DATE_FORMAT(min(e.fecha), '%Y/%m/%d') as inicio, DATE_FORMAT(max(e.fecha), '%Y/%m/%d') as final, 
                sum(cs.habitantes) as habitantes, 
                sum(cs.num_hab) as num_hab, 
                COUNT(cs.id) AS viv_existentes, 
                c.num_viviendas_actual,
                COUNT(e.disponible) AS disponible,
                round(((COUNT(e.disponible)/COUNT(cs.id))*100), 2) as cob,

                (select count(id) from ee1 where (ecin+  ecia+ecpn+ ecpa) >0  and comunidad = c.id and estado = 1)  as viv_pos,
                (select count(id) from ee1 where (ecin + ecia) >0 and comunidad = c.id and estado = 1 )  as pos_intra,
                (select count(id) from ee1 where (ecpn + ecpa) >0 and  comunidad = c.id and estado = 1 )  as pos_peri,


                (select count(id) from ee1 where (ecin+ ecpn) >0 and  comunidad = c.id and estado = 1)  as pos_ninfas,
                (select count(id) from ee1 where (ecin) >0 and  comunidad = c.id and estado = 1)  as pos_ninfas_intra,
                (select count(id) from ee1 where ecpn >0 and comunidad = c.id and estado = 1)  as pos_ninfas_peri,

                (select count(id) from casa where vm_intra = 1 and comunidad = c.id) as vm_intra_si,
                (select count(id) from casa where vm_intra = 0 and comunidad = c.id) as vm_intra_no,

                (select count(id) from casa where vm_peri = 1 and comunidad = c.id) as vm_peri_si,
                (select count(id) from casa where vm_peri = 0 and comunidad = c.id) as vm_peri_no,
          

                 sum(e.ecin) as ecin,  sum(e.ecia) as ecia, sum(e.ecpn) as ecpn, sum(e.ecpa) as ecpa, 
                 sum(e.lcipd) as lcipd, sum(e.lcicm) as lcicm, sum(e.lcith) as lcith, sum(e. lciot) as lciot , sum(e.lcppd) as lcppd,
                 sum(e.lcpga) as lcpga, sum(e.lcpcl) as lcpcl, sum(e.lcpcj) as lcpcj, sum(e.lcpz) as lcpz, sum(e.lcpot) as lcpot, cs.altitud, cs.latitud, cs.longitud


                FROM ee1 e
                inner join casa cs on cs.id = e.casa
                inner join comunidad c on c.id = cs.comunidad
                inner join municipio m on m.id = c.municipio
                where m.id = ${pool.escape(municipio)} and e.estado = 1 and (r.fecha between ${pool.escape(fecha1)} and ${pool.escape(fecha2)}) 
                group by c.id
                order by c.id  asc`;
        const [rows] = await pool.query(sql)
        return rows
    }


    habilitarEdicion = async (comunidad) => {

        const sql_ = `update ee1 set estado = 0 WHERE   comunidad = ${pool.escape(comunidad)} AND estado = 1 `;
        const result = await pool.query(sql_);
        console.log(result)
        if (result[0].affectedRows > 0) {
            return true
        } else return false

    }


    validar = async (municipio, fecha, user) => {

        const sql_ = `update ee1 set estado = 2, fecha_remision_mun = ${pool.escape(fecha)}, jefeBrigada = ${pool.escape(user)}
            WHERE   municipio = ${pool.escape(municipio)} AND estado = 1 `;
        const result = await pool.query(sql_);
        if (result[0].affectedRows > 0) {

            // const sql_comunidad = `select c.id,  count(cs.id) as casas from casa cs inner join comunidad c on c.id = cs.comunidad where c.municipio = ${pool.escape(municipio)} group by c.id `;
            // const [result] = await pool.query(sql_comunidad);
            // console.log(result)
            // for (let r of result) {
            //     const sql_ = `update comunidad set usuario_eval_actual = null, num_viviendas_actual= ${pool.escape(r.casas)} where id = ${pool.escape(r.id)}`; // actualizar el numer de viviendas para la proxima actividad. Este dato servirá para mostrar en el formulario ee2->viviendas->prog
            //     await pool.query(sql_);
            // }
            return true
        } else return false

    }
}
