
const pool = require('../../bdConfig.js')

module.exports = class EE2 {

    // (select count(vm_intra) from casa where id = ${pool.escape()})  as viv_mejorada_intra,
    // cs.vm_intra, cs.vm_peri,

    listar = async (user, municipio) => {
        const sql =
            `SELECT  e.id, c.nombre as comunidad, max(e.prerociado) as prerociado,
            
                DATE_FORMAT(min(e.fecha), '%Y/%m/%d') as inicio, DATE_FORMAT(max(e.fecha), '%Y/%m/%d') as final, e.estado,
                sum(cs.habitantes) as habitantes, 
                sum(cs.num_hab) as num_hab, 
                COUNT(cs.id) AS viv_existentes, 
                c.num_viviendas_actual,
                COUNT(e.disponible) AS disponible,
                round(((COUNT(e.disponible)/COUNT(cs.id))*100), 2) as cob,

                (select count(id) from ee1 where (ecin+  ecia+ecpn+ ecpa) >0 and usuario = ${pool.escape(user)} and comunidad = c.id and estado = 1)  as viv_pos,
                (select count(id) from ee1 where (ecin + ecia) >0 and usuario = ${pool.escape(user)} and comunidad = c.id and estado = 1 )  as pos_intra,
                (select count(id) from ee1 where (ecpn + ecpa) >0 and usuario = ${pool.escape(user)} and comunidad = c.id and estado = 1 )  as pos_peri,


                (select count(id) from ee1 where (ecin+ ecpn) >0 and usuario = ${pool.escape(user)} and comunidad = c.id and estado = 1)  as pos_ninfas,
                (select count(id) from ee1 where (ecin) >0 and usuario = ${pool.escape(user)} and comunidad = c.id and estado = 1)  as pos_ninfas_intra,
                (select count(id) from ee1 where ecpn >0 and usuario = ${pool.escape(user)} and comunidad = c.id and estado = 1)  as pos_ninfas_peri,

                (select count(id) from casa where vm_intra = 1 and comunidad = c.id) as vm_intra_si,
                (select count(id) from casa where vm_intra = 0 and comunidad = c.id) as vm_intra_no,

                (select count(id) from casa where vm_peri = 1 and comunidad = c.id) as vm_peri_si,
                (select count(id) from casa where vm_peri = 0 and comunidad = c.id) as vm_peri_no,
          

                 sum(e.ecin) as ecin,  sum(e.ecia) as ecia, sum(e.ecpn) as ecpn, sum(e.ecpa) as ecpa, 
                 sum(e.lcipd) as lcipd, sum(e.lcicm) as lcicm, sum(e.lcith) as lcith, sum(e. lciot) as lciot , sum(e.lcppd) as lcppd,
                 sum(e.lcpga) as lcpga, sum(e.lcpcl) as lcpcl, sum(e.lcpcj) as lcpcj, sum(e.lcpz) as lcpz, sum(e.lcpot) as lcpot, cs.altitud, cs.latitud, cs.longitud


                FROM ee1 e
                inner join casa cs on cs.id = e.casa
                inner join comunidad c on c.id = cs.comunidad
                inner join municipio m on m.id = c.municipio
                where m.id = ${pool.escape(municipio)} and  e.usuario = ${pool.escape(user)}
                group by c.id
                order by c.id  asc`;
        const [rows] = await pool.query(sql)
        const sqlOtros =
            `SELECT    m.nombre as municipio,  r.nombre as red
                FROM municipio m 
                inner join red r on r.id = m.red
                where m.id = ${pool.escape(municipio)}`
        const [rowsOtros] = await pool.query(sqlOtros)
        // console.log(rows)
        return [rows, rowsOtros]
    }


    buscar = async (fecha1, fecha2, municipio, user) => {
        const sql =
            `SELECT  e.id, c.nombre as comunidad, max(e.prerociado) as prerociado,
            
                DATE_FORMAT(min(e.fecha), '%Y/%m/%d') as inicio, DATE_FORMAT(max(e.fecha), '%Y/%m/%d') as final, 
                sum(cs.habitantes) as habitantes, 
                sum(cs.num_hab) as num_hab, e.estado,
                COUNT(cs.id) AS viv_existentes, 
                c.num_viviendas_actual,
                COUNT(e.disponible) AS disponible,
                round(((COUNT(e.disponible)/COUNT(cs.id))*100), 2) as cob,

                (select count(id) from ee1 where (ecin+  ecia+ecpn+ ecpa) >0 and usuario = ${pool.escape(user)} and comunidad = c.id and estado = 1)  as viv_pos,
                (select count(id) from ee1 where (ecin + ecia) >0 and usuario = ${pool.escape(user)} and comunidad = c.id and estado = 1 )  as pos_intra,
                (select count(id) from ee1 where (ecpn + ecpa) >0 and usuario = ${pool.escape(user)} and comunidad = c.id and estado = 1 )  as pos_peri,


                (select count(id) from ee1 where (ecin+ ecpn) >0 and usuario = ${pool.escape(user)} and comunidad = c.id and estado = 1)  as pos_ninfas,
                (select count(id) from ee1 where (ecin) >0 and usuario = ${pool.escape(user)} and comunidad = c.id and estado = 1)  as pos_ninfas_intra,
                (select count(id) from ee1 where ecpn >0 and usuario = ${pool.escape(user)} and comunidad = c.id and estado = 1)  as pos_ninfas_peri,

                (select count(id) from casa where vm_intra = 1 and comunidad = c.id) as vm_intra_si,
                (select count(id) from casa where vm_intra = 0 and comunidad = c.id) as vm_intra_no,

                (select count(id) from casa where vm_peri = 1 and comunidad = c.id) as vm_peri_si,
                (select count(id) from casa where vm_peri = 0 and comunidad = c.id) as vm_peri_no,
          

                 sum(e.ecin) as ecin,  sum(e.ecia) as ecia, sum(e.ecpn) as ecpn, sum(e.ecpa) as ecpa, 
                 sum(e.lcipd) as lcipd, sum(e.lcicm) as lcicm, sum(e.lcith) as lcith, sum(e. lciot) as lciot , sum(e.lcppd) as lcppd,
                 sum(e.lcpga) as lcpga, sum(e.lcpcl) as lcpcl, sum(e.lcpcj) as lcpcj, sum(e.lcpz) as lcpz, sum(e.lcpot) as lcpot, cs.altitud, cs.latitud, cs.longitud


                FROM ee1 e
                inner join casa cs on cs.id = e.casa
                inner join comunidad c on c.id = cs.comunidad 
                inner join municipio m on m.id = c.municipio
                where m.id = ${pool.escape(municipio)} and e.usuario = ${pool.escape(user)} and (${pool.escape(fecha1)} >= e.fecha or e.fecha <=  ${pool.escape(fecha2)}) 
                group by c.id
                order by c.id  asc`;
        const [rows] = await pool.query(sql)
        return rows
    }


}
