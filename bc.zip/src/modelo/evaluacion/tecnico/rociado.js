
const pool = require('../../bdConfig.js')

module.exports = class Rociado {


    listar = async (usuario, comunidad) => {
        const sql =
            `SELECT  r.id, cs.id as idcasa, cs.cv, cs.jefefamilia, cs.habitantes, if(r.cerrada, 'SI', 'NO') AS cerrada, if(r.renuente, 'SI', 'NO') AS renuente, r.cerrada as cerrada_n, r.renuente as renuente_n, 
                r.idr, r.idnr, r.corrales, r.gallineros, r.conejeras, r.zarzo, r.otros, r.numeroCargas, i.unidad,  r.dosis, r.lote, r.estado, DATE_FORMAT(r.fecha,"%Y/%m/%d") AS fecha, 
                r.insecticida, r.ciclo, i.nombre as nombreInsecticida, ci.ciclo as nombreCiclo, r.observaciones, u.id as idUsuarioBrigada, concat(u.nombre, ' ', u.ap1) as usuarioBrigada
                FROM rociado r
                left join insecticida i on i.id = r.insecticida
                left join clicor ci on ci.id = r.ciclo
                inner join casa cs on cs.id = r.casa
                left join usuario u on u.id = r.usuarioBrigada
                inner join comunidad c on c.id = cs.comunidad
                where  r.usuario = ${pool.escape(usuario)} and c.id = ${pool.escape(comunidad)}
                order by r.id  desc`;
        const [rows] = await pool.query(sql)
        // console.log(usuario, comunidad, rows,'parametros listar ee-1')

        return rows
    }


    buscar = async (fecha1, fecha2, usuario, comunidad) => {
        const sql =
            `SELECT  r.id, cs.id as idcasa, cs.cv, cs.jefefamilia, cs.habitantes, if(r.cerrada, 'SI', 'NO') AS cerrada, if(r.renuente, 'SI', 'NO') AS renuente, r.cerrada as cerrada_n, r.renuente as renuente_n, 
                r.idr, r.idnr, r.corrales, r.gallineros, r.conejeras, r.zarzo, r.otros, r.numeroCargas, i.unidad, r.dosis, r.lote, r.estado, DATE_FORMAT(r.fecha,"%Y/%m/%d") AS fecha, 
                r.insecticida, r.ciclo, i.nombre as nombreInsecticida, ci.ciclo as nombreCiclo, r.observaciones, u.id as idUsuarioBrigada, concat(u.nombre, ' ', u.ap1) as usuarioBrigada
                FROM rociado r
                inner join insecticida i on i.id = r.insecticida
                inner join clicor ci on ci.id = r.ciclo
                inner join usuario u on u.id = r.usuarioBrigada
                inner join casa cs on cs.id = r.casa
                inner join comunidad c on c.id = cs.comunidad
             WHERE  (r.fecha betwwen ${pool.escape(fecha1)} and ${pool.escape(fecha2)}) and r.usuario = ${pool.escape(usuario)} and c.id = ${pool.escape(comunidad)}   order by r.id  desc`;
        // console.log(fecha1, fecha2, usuario, comunidad, sql)
        const [rows] = await pool.query(sql)
        return rows
    }

    listarUsuarios = async (municipio) => {
        const sql =
            `SELECT id, if(ap2,concat(nombre, ' ', ap1,' ',ap2) , concat(nombre, ' ', ap1) ) as label FROM usuario 
            where rol = 2 and municipio = ${pool.escape(municipio)}`
        const [rows] = await pool.query(sql)

        return rows
    }

    listarMunicipios = async () => {
        const sql =
            `SELECT  id as value, nombre as label FROM municipio`
        const [rows] = await pool.query(sql)
        return rows
    }
    listarCiclos = async () => {
        const sql =
            `SELECT  id , ciclo as label FROM clicor`
        const [rows] = await pool.query(sql)
        return rows
    }
    listarInsecticida = async () => {
        const sql =
            `SELECT  id, concat(nombre, ' ', unidad)  as label FROM insecticida`
        const [rows] = await pool.query(sql)
        return rows
    }

    listarComunidad = async (municipio) => {
        const sql =
            `SELECT  id as value, nombre as label FROM comunidad where municipio = ${pool.escape(municipio)}`
        const [rows] = await pool.query(sql)
        return rows
    }

    listarCasas = async (comunidad) => {
        const sql =
            `SELECT id, concat(cv,' - ', jefefamilia) as label FROM casa where comunidad = ${pool.escape(comunidad)}`
        const [rows] = await pool.query(sql)
        const sqlOtros =
            `SELECT   c.nombre as comunidad, m.nombre as municipio, h.nombre as hospital, r.nombre as red
            FROM comunidad c
            inner join hospital h on h.id = c.est
            inner join municipio m on m.id = c.municipio
            inner join red r on r.id = m.red
            where c.id = ${pool.escape(comunidad)}`
        const [rowsOtros] = await pool.query(sqlOtros)
        return [rows, rowsOtros]
    }


    insertar = async (datos, comunidad) => {

        const sqlExists =
            `SELECT * FROM casa  WHERE id = ${pool.escape(datos.casa)} and comunidad = ${pool.escape(comunidad)} `;
        const [result] = await pool.query(sqlExists)
        if (result.length > 0) {
            const sqlExists =
                `SELECT * FROM rociado  WHERE casa = ${pool.escape(datos.casa)} and comunidad = ${pool.escape(datos.comunidad)} and (estado = 0 or estado = 1) `;
            const [result] = await pool.query(sqlExists)
            // console.log(result, ' Daos del rociado')

            if (result.length === 0) {

                const sqlExists =
                    `SELECT usuario_rociador_actual FROM comunidad  WHERE id = ${pool.escape(comunidad)}`;
                const [result] = await pool.query(sqlExists) // se verifica que el usuario solicitante se quien esta llenando la informacion desde un principio
                if (!result[0].usuario_rociador_actual) {
                    const sqlUpdated =
                        `update comunidad set usuario_rociador_actual = ${pool.escape(datos.usuario)}  WHERE id = ${pool.escape(comunidad)}`;
                    await pool.query(sqlUpdated)
                    const [result] = await pool.query("INSERT INTO rociado SET  ?", datos)
                    if (result.insertId > 0) {
                        return true
                    } else return false
                }
                if (result[0].usuario_rociador_actual == datos.usuario) {

                    const [result] = await pool.query("INSERT INTO rociado set  ?", datos)
                    if (result.insertId > 0) {
                        return true
                    } else return false
                } else return -3
            } else return -2
        } else return -1

    }



    actualizar = async (datos) => {
        const sqlExists =
            `SELECT * FROM rociado  WHERE casa = ${pool.escape(datos.casa)} and estado =  0 and comunidad = ${pool.escape(datos.comunidad)} and id != ${pool.escape(datos.id)} `;
        const [result] = await pool.query(sqlExists)
        if (result.length === 0) {

            const sqlExists =
                `SELECT * FROM rociado  WHERE casa = ${pool.escape(datos.casa)} and comunidad = ${pool.escape(datos.comunidad)} and estado = 0 and id !=  ${pool.escape(datos.id)}`;
            const [result] = await pool.query(sqlExists)
            if (result.length === 0) {

                const sql_ = `UPDATE rociado SET
                       casa  = ${pool.escape(datos.casa)},
                      
                        idr = ${pool.escape(datos.idr)},
                        idnr = ${pool.escape(datos.idnr)},
                       corrales  = ${pool.escape(datos.corrales)},
                        gallineros = ${pool.escape(datos.gallineros)},
                        conejeras = ${pool.escape(datos.conejeras)},
                        zarzo = ${pool.escape(datos.zarzo)},
                        otros = ${pool.escape(datos.otros)},
                        cerrada= ${pool.escape(datos.cerrada)},
                        renuente = ${pool.escape(datos.renuente)},
                        numeroCargas = ${pool.escape(datos.numeroCargas)},
                       modified  = ${pool.escape(datos.fecha)},
                       user_modified  = ${pool.escape(datos.usuario)}
                        WHERE id = ${pool.escape(datos.id)} and estado = 0`;
                const result = await pool.query(sql_);

                if (result[0].affectedRows > 0) {
                    return true
                } else return false
            } else return -2
        } else return -1
    }



    eliminar = async (id) => {

        const sql_ = `delete from rociado
                        WHERE id = ${pool.escape(id)} and estado = 0`;
        const result = await pool.query(sql_);
        if (result[0].affectedRows > 0) {
            return true
        } else return false

    }

    // la validacion dela informacion se lo realizará solo cuando ya haya completado con toda la actividad rociando a todas las viviendas de la comunidad

    validar = async (datos) => {

        let codigo = 'C-' +datos.comunidad + '' + datos.fecha.split('-')[0] + '' + datos.fecha.split('-')[1] + datos.fecha.split('-')[2].split(' ')[0] + '-' +
        datos.fecha.split('-')[2].split(' ')[1].split(':')[0]+' '+datos.fecha.split('-')[2].split(' ')[1].split(':')[2]+''+datos.fecha.split('-')[2].split(' ')[1].split(':')[2]
        const sql_ = `  update rociado set 
                        estado = 1, 
                        insecticida = ${pool.escape(datos.insecticida)},
                        dosis = ${pool.escape(datos.dosis)},
                        ciclo = ${pool.escape(datos.ciclo)},
                        lote = ${pool.escape(datos.lote)},
                        observaciones = ${pool.escape(datos.observaciones)},
                        usuarioBrigada = ${pool.escape(datos.usuarioBrigada)},
                        fecha_remision = ${pool.escape(datos.fecha)} ,
                        codigo = ${pool.escape(codigo)} 
                        WHERE  usuario = ${pool.escape(datos.user)} AND estado = 0 and comunidad = ${pool.escape(datos.comunidad)} `;
        const result = await pool.query(sql_);
        if (result[0].affectedRows > 0) {
            return true
        } else return false

    }

}
