
const pool = require('../../bdConfig.js')

module.exports = class EE1 {


    listar = async (usuario, comunidad) => {
        // console.log(usuario, comunidad, 'parametros listar ee-1')
        const sql =
            `SELECT  e.id, cs.id as idcasa, cs.cv, cs.jefefamilia, e.inicio, e.final, e.prerociado,

                SEC_TO_TIME(TIME_TO_SEC(e.final) - TIME_TO_SEC(e.inicio)) AS total,

                cs.num_hab, cs.habitantes, DATE_FORMAT(cs.fecha_rociado, "%Y/%m/%d") AS  fecha_rociado, 
                
                cs.vm_intra, cs.vm_peri,DATE_FORMAT(e.fecha, "%Y/%m/%d") as fecha, 

                 e.ecin,  e.ecia,e.ecpn, e.ecpa, 
                e.lcipd, e.lcicm, e.lcith, e. lciot , e.lcppd, e.lcpga, e.lcpcl, e.lcpcj, e.lcpz, e.lcpot, e.estado, e.fecha_remision, cs.altitud, cs.latitud, cs.longitud, 
                m.nombre as comunidad, m.nombre as municipio, e.disponible
                FROM ee1 e
                inner join casa cs on cs.id = e.casa
                inner join comunidad c on c.id = cs.comunidad
                inner join municipio m on m.id = c.municipio
                where e.usuario = ${pool.escape(usuario)} and c.id = ${pool.escape(comunidad)}
                order by cs.cv  asc`;
        const [rows] = await pool.query(sql)
        return rows
    }


    buscar = async (fecha1, fecha2, usuario, comunidad) => {
        const sql =
            `SELECT  e.id, cs.id as idcasa, cs.cv, cs.jefefamilia, e.inicio, e.final, e.prerociado,

                SEC_TO_TIME(TIME_TO_SEC(e.final) - TIME_TO_SEC(e.inicio)) AS total,

                cs.num_hab, cs.habitantes, DATE_FORMAT(cs.fecha_rociado,"%Y/%m/%d") AS  fecha_rociado, 
                
                cs.vm_intra, cs.vm_peri, DATE_FORMAT(e.fecha, "%Y/%m/%d") as fecha,

                 e.ecin,  e.ecia,e.ecpn, e.ecpa, 
                e.lcipd, e.lcicm, e.lcith, e. lciot , e.lcppd, e.lcpga, e.lcpcl, e.lcpcj, e.lcpz, e.lcpot,  e.estado, e.fecha_remision, cs.altitud, cs.latitud, cs.longitud, 
                m.nombre as comunidad, m.nombre as municipio, e.disponible
                FROM ee1 e
                inner join casa cs on cs.id = e.casa
                inner join comunidad c on c.id = cs.comunidad
                inner join municipio m on m.id = c.municipio
             WHERE  (e.fecha between ${pool.escape(fecha1)} and  ${pool.escape(fecha2)}) and e.usuario = ${pool.escape(usuario)} and c.id = ${pool.escape(comunidad)}`;
        const [rows] = await pool.query(sql)
        return rows
    }

    listarUsuarios = async (usuario) => {
        const sql =
            `SELECT id, if(ap2,concat(nombre, ' ', ap1,' ',ap2) , concat(nombre, ' ', ap1) ) as label FROM usuario 
            where id != ${pool.escape(usuario)} and rol = 3`
        const [rows] = await pool.query(sql)
        console.log(rows, usuario)
        return rows
    }

    listarMunicipios = async () => {
        const sql =
            `SELECT  id as value, nombre as label FROM municipio`
        const [rows] = await pool.query(sql)
        return rows
    }

    listarComunidad = async (municipio) => {
        const sql =
            `SELECT  id as value, nombre as label FROM comunidad where municipio = ${pool.escape(municipio)}`
        const [rows] = await pool.query(sql)
        return rows
    }

    listarCasas = async (comunidad) => {
        const sql =
            `SELECT id, concat(cv,' - ', jefefamilia) as label FROM casa where comunidad = ${pool.escape(comunidad)}`
        const [rows] = await pool.query(sql)
        const sqlOtros =
            `SELECT   c.nombre as comunidad, m.nombre as municipio, h.nombre as hospital, r.nombre as red
            FROM comunidad c
            inner join hospital h on h.id = c.est
            inner join municipio m on m.id = c.municipio
            inner join red r on r.id = m.red
            where c.id = ${pool.escape(comunidad)}`
        const [rowsOtros] = await pool.query(sqlOtros)
        return [rows, rowsOtros]
    }


    insertar = async (datos, comunidad) => {

        const sqlExists =
            `SELECT * FROM casa  WHERE id = ${pool.escape(datos.casa)} and comunidad = ${pool.escape(comunidad)} `;
        const [result] = await pool.query(sqlExists)

        if (result.length > 0) {

            const sqlExists =
                `SELECT * FROM ee1  WHERE casa = ${pool.escape(datos.casa)} and comunidad = ${pool.escape(datos.comunidad)} and (estado = 0 or estado = 1) `;
            const [result] = await pool.query(sqlExists)
            if (result.length === 0) {

                const sqlExists =
                    `SELECT usuario_eval_actual FROM comunidad  WHERE id = ${pool.escape(comunidad)}`;
                const [result] = await pool.query(sqlExists) // se verifica que el usuario solicitante se quien esta llenando la informacion desde un principio
                // console.log(result[0].usuario_eval_actual)
                if (!result[0].usuario_eval_actual) {
                    const sqlUpdated =
                        `update comunidad set usuario_eval_actual = ${pool.escape(datos.usuario)}  WHERE id = ${pool.escape(comunidad)}`;
                    await pool.query(sqlUpdated)
                    const [result] = await pool.query("INSERT INTO ee1 SET  ?", datos)
                    if (result.insertId > 0) {
                        return true
                    } else return false
                }
                if (result[0].usuario_eval_actual == datos.usuario) {

                    const [result] = await pool.query("INSERT INTO ee1 SET  ?", datos)
                    if (result.insertId > 0) {
                        return true
                    } else return false
                } else return -3
            } else return -2
        } else return -1

    }



    actualizar = async (datos) => {
        const sqlExists =
            `SELECT * FROM ee1  WHERE casa = ${pool.escape(datos.casa)}  and estado = 0 and comunidad = ${pool.escape(datos.comunidad)} and id != ${pool.escape(datos.id)}`;
        const [result] = await pool.query(sqlExists)
        // console.log(result, sqlExists)
        if (result.length === 0) {

            const sqlExists =
                `SELECT * FROM ee1  WHERE casa = ${pool.escape(datos.casa)} and comunidad = ${pool.escape(datos.comunidad)} and estado = 0 and id !=  ${pool.escape(datos.id)}`;
            const [result] = await pool.query(sqlExists)
            if (result.length === 0) {

                const sql_ = `UPDATE ee1 SET
                       casa  = ${pool.escape(datos.casa)},
                       inicio  = ${pool.escape(datos.inicio)},
                        final = ${pool.escape(datos.final)},
                        ecin = ${pool.escape(datos.ecin)},
                       ecia  = ${pool.escape(datos.ecia)},
                        ecpn = ${pool.escape(datos.ecpn)},
                        ecpa = ${pool.escape(datos.ecpa)},
                       lcipd  = ${pool.escape(datos.lcipd)},
                        lcicm = ${pool.escape(datos.lcicm)},
                        lcith = ${pool.escape(datos.lcith)},
                        lciot = ${pool.escape(datos.lciot)},
                        lcppd = ${pool.escape(datos.lcppd)},
                        lcpga= ${pool.escape(datos.lcpga)},
                        lcpcl = ${pool.escape(datos.lcpcl)},
                        lcpcj = ${pool.escape(datos.lcpcj)},
                        lcpz = ${pool.escape(datos.lcpz)},
                        lcpot = ${pool.escape(datos.lcpot)},
                        usuario1 = ${pool.escape(datos.usuario1)},
                        prerociado = ${pool.escape(datos.prerociado)},
                        disponible = ${pool.escape(datos.disponible)},
                       fecha  = ${pool.escape(datos.fecha)}
                        WHERE id = ${pool.escape(datos.id)} and estado = 0`;
                const result = await pool.query(sql_);

                if (result[0].affectedRows > 0) {
                    return true
                } else return false
            } else return -2
        } else return -1
    }



    eliminar = async (id) => {

        const sql_ = `delete from ee1
                        WHERE id = ${pool.escape(id)} and estado = 0`;
        const result = await pool.query(sql_);
        if (result[0].affectedRows > 0) {
            return true
        } else return false

    }

    // la validacion dela informacion se lo realizará solo si el tecnico haya completado con toda la actividad visitando a todas las viviendas de la comunidad
    // num_viviendas_actual= ${pool.escape(casas.length)} // esta funcion va para el administrador , 
    validar = async (fecha, usuario, comunidad,) => {

        const sqlCasas = `select * from casa where comunidad = ${pool.escape(comunidad)}`
        const sqlEE1 = `select * from ee1 where usuario = ${pool.escape(usuario)} and estado = 0 and comunidad = ${pool.escape(comunidad)}`

        const [casas] = await pool.query(sqlCasas)
        const [ee1] = await pool.query(sqlEE1)


        // console.log(casas.length, ee1.length)

        if (casas.length != ee1.length) { // colo sera permitido validar informacion cuando se haya completado con todas las viviendas de la comunidad
            return -1
        }


        // calculo de la cobertura de la actividad, debe ser mayor al 70%
        let c = 0
        for (let e of ee1) {
            if (parseInt(e.disponible))
                c++
        }


        if (((c * 100) / ee1.length < 70)) {
            return -2
        }

        let codigo = 'C-' + comunidad + '' + fecha.split('-')[0] + '' + fecha.split('-')[1] + fecha.split('-')[2].split(' ')[0] + '-' +
            fecha.split('-')[2].split(' ')[1].split(':')[0] + ' ' + fecha.split('-')[2].split(' ')[1].split(':')[2] + '' + fecha.split('-')[2].split(' ')[1].split(':')[2]

        const sql_ = `update ee1 set estado = 1, fecha_remision = ${pool.escape(fecha)}, num_viviendas_actual = ${pool.escape(casas.length)}, codigo = ${pool.escape(codigo)}
                        WHERE   usuario = ${pool.escape(usuario)} AND estado = 0 and comunidad = ${pool.escape(comunidad)} `;
        const result = await pool.query(sql_);
        if (result[0].affectedRows > 0) {
            for (let e of ee1) {
                const sql_ = `update casa set fecha_rociado = ${pool.escape(fecha.split(' ')[0])}
                WHERE   id = ${pool.escape(e.casa)} `;
                await pool.query(sql_);
            }


            return true
        } else return false

    }

}
