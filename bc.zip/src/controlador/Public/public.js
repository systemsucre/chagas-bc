const { Router } = require("express")
const Usuario  = require('../../modelo/admin/usuario.js')

// import nodemailer from "nodemailer";
// import { CLAVEGMAIL } from '../../config.js'
// import pool from '../../modelo/bdConfig.js'

//const modelo from "../modelo/usuario.js"
// desde esta plantilla se importa las funcionalidades de los controladores de los modulos


const rutas = Router()
const usuario = new Usuario()



rutas.get("/get-service",  async (req, res) => {
    
    try {
        const resultado = await servicio.getService(req.query.id)
        return res.json({ data:resultado, ok: true, msg: "Espere que el administrador valide su nueva cuenta" });
    } catch (error) {
        console.log(error)
        return res.json({ msg: 'Error en el Servidor', ok: false })
    }
})







rutas.get("/listar",  async (req, res) => {

    try {
        const resultado = await usuario.listarMedicos()
    
        return res.json({ data:resultado, ok: true, msg: "Espere que el administrador valide su nueva cuenta" });


    } catch (error) {
        console.log(error)
        return res.json({ msg: 'Error en el Servidor', ok: false })
    }
})


















module.exports = rutas