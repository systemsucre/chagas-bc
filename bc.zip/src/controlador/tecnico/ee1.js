const { Router } = require("express")
const EE1 = require("../../modelo/evaluacion/tecnico/ee1.js")
const { insertar, editar, eliminar, completar, } = require('../../validacion/evaluacion/tecnico/ee1.js')


const rutas = Router()
const ee1 = new EE1()

rutas.post("/listar", async (req, res) => {
    // console.log(req)
    try {
        const resultado = await ee1.listar(req.body.fecha_.split(' ')[0], req.body.user, req.body.comunidad)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})

rutas.post("/buscar", completar, async (req, res) => {
    try {
        const resultado = await ee1.buscar(req.body.fecha1, req.body.fecha2, req.body.user, req.body.comunidad)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})

rutas.post("/listar-municipios", async (req, res) => {
    try {

        const resultado = await ee1.listarMunicipios()
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})

rutas.post("/listar-comunidad", async (req, res) => {
    try {

        const resultado = await ee1.listarComunidad(req.body.id)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})

rutas.post("/listar-casas", async (req, res) => {
    try {
        console.log(req.body, 'list house')

        const resultado = await ee1.listarCasas(req.body.comunidad)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})

rutas.post("/listar-usuarios", async (req, res) => {
    try {
        // console.log(req.body, 'llamando a listar munic')

        const resultado = await ee1.listarUsuarios(req.body.municipio_id_tec, req.body.user)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})


rutas.post("/guardar", insertar, async (req, res) => {

    try {
        const {
            casa,
            inicio, final, ecin, ecia, ecpn, ecpa, lcipd, lcicm, lcith, lciot, lcppd,
            lcpga, lcpcl, lcpcj, lcpz, lcpot, usuario1, prerociado,
            fecha_, user } = req.body
        const datos = {
            casa,
            inicio, final, ecin, ecia, ecpn, ecpa, lcipd, lcicm, lcith, lciot, lcppd,
            lcpga, lcpcl, lcpcj, lcpz, lcpot, usuario1, fecha: fecha_.split(' ')[0], usuario: user, prerociado,
        }
        const resultado = await ee1.insertar(datos)
        if (resultado === -1) {
            return res.json({ ok: false, msg: 'Esta vivienda no esta registrada' })
        }
        if (resultado === -2) {
            return res.json({ ok: false, msg: 'Ya existe un registro con este CV para hoy "sin fecha de emision"' })
        }

        if (!resultado) {
            return res.json({ ok: false, msg: 'No se ha podido guardar el registro, intentelo nuvamente..!!!' })
        }
        return res.json({ ok: true, msg: 'Registro Guardado' })

    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})



rutas.post("/actualizar", editar, async (req, res) => {
    try {
        const { id,
            casa,
            inicio, final, ecin, ecia, ecpn, ecpa, lcipd, lcicm, lcith, lciot, lcppd,
            lcpga, lcpcl, lcpcj, lcpz, lcpot, usuario1, prerociado,
            fecha_ } = req.body
        const datos = {
            id,
            casa,
            inicio, final, ecin, ecia, ecpn, ecpa, lcipd, lcicm, lcith, lciot, lcppd,
            lcpga, lcpcl, lcpcj, lcpz, lcpot, usuario1, fecha: fecha_.split(' ')[0], prerociado,
        }
        if ((ecin + ecia) != (lcppd + lcicm + lcith + lciot)) {
            return res.json({ ok: false, msg: 'Debe coincidir la sumatoia de Los ejemplares capturados en el interior del domicilio ' })

        }
        if ((ecpn + ecpa) != (lcppd + lcpga + lcpcl + lcpcj + lcpz + lcpot)) {
            return res.json({ ok: false, msg: 'Debe coincidir la sumatoia de Los ejemplares capturados en el PERI/Exterior del domicilio ' })
        }
        const resultado = await ee1.actualizar(datos)

        if (resultado === -1) {
            return res.json({ ok: false, msg: 'Numero control vectorial ya esta registrada' })
        }

        if (!resultado) {
            return res.json({ msg: 'Actualizacion Fállida', ok: false })
        }
        return res.json({ ok: true, msg: 'Registro actualizado' })

    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})



rutas.post("/eliminar", eliminar, async (req, res) => {
    try {
        const id = req.body.id;
        const resultado = await ee1.eliminar(id)
        if (!resultado) {
            return res.json({ msg: 'Ops! No se ha eliminado el registro.', ok: false })
        }
        return res.json({ ok: true, msg: 'Registro eliminado correctamete' })

    } catch (error) {
        console.log(error)
        return res.json({ error: 500, msg: error.sqlMessage + '. Puede existir valores dependientes a este registro. COnsulte con el administrador' });
    }
})

rutas.post("/completar", completar, async (req, res) => {
    try {
        const fecha = req.body.fecha_;
        const fecha1 = req.body.fecha1;
        const fecha2 = req.body.fecha2;
        const resultado = await ee1.completar(fecha, fecha1, fecha2)
        if (!resultado) {
            return res.json({ msg: 'Ops! No se ha podido completar la accion!. No existen registros para enviar/', ok: false })
        }
        return res.json({ ok: true, msg: 'El registro se ha enviado correctamete' })

    } catch (error) {
        console.log(error)
        return res.json({ error: 500, msg: error.sqlMessage });
    }
})


module.exports = rutas;