const { Router } = require("express")
const EE2 = require("../../../modelo/evaluacion/tecnico/ee2.js")
const { buscar } = require("../../../validacion/evaluacion/tecnico/ee2.js") 


const rutas = Router()
const ee2 = new EE2()

rutas.post("/listar", async (req, res) => {
    // console.log(req)
    try {
        const resultado = await ee2.listar(req.body.user, req.body.municipio_id_tec)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})

rutas.post("/buscar", buscar, async (req, res) => {
    try {
        const resultado = await ee2.buscar(req.body.fecha1, req.body.fecha2, req.body.municipio_id_tec, req.body.user)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage }); 
    }
})



module.exports = rutas;