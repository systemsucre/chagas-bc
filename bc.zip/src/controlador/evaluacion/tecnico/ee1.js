const { Router } = require("express")
const EE1 = require("../../../modelo/evaluacion/tecnico/ee1.js")
const { insertar, editar, eliminar, completar, } = require('../../../validacion/evaluacion/tecnico/ee1.js')


const rutas = Router()
const ee1 = new EE1()

rutas.post("/listar", async (req, res) => {
    // console.log(req)
    try {
        const resultado = await ee1.listar( req.body.user, req.body.comunidad)
        return res.json({ data: resultado, ok: true })
    } catch (error) { 
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})

rutas.post("/buscar", completar, async (req, res) => {
    try {
        const resultado = await ee1.buscar(req.body.fecha1, req.body.fecha2, req.body.user, req.body.comunidad)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})

rutas.post("/listar-municipios", async (req, res) => {
    try {

        const resultado = await ee1.listarMunicipios()
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})

rutas.post("/listar-comunidad", async (req, res) => {
    try {

        const resultado = await ee1.listarComunidad(req.body.id)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})

rutas.post("/listar-casas", async (req, res) => {
    try {
        console.log(req.body, 'list house')

        const resultado = await ee1.listarCasas(req.body.comunidad)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})

rutas.post("/listar-usuarios", async (req, res) => {
    try {
        // console.log(req.body, 'llamando a listar munic')

        const resultado = await ee1.listarUsuarios( req.body.user)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})


rutas.post("/guardar", insertar, async (req, res) => {

    try {
        let {
            casa, comunidad,municipio,
            inicio, final, ecin, ecia, ecpn, ecpa, lcipd, lcicm, lcith, lciot, lcppd,
            lcpga, lcpcl, lcpcj, lcpz, lcpot, usuario1, prerociado, disponible,
            fecha_, user } = req.body
        if (!disponible) {
            ecin = 0
            ecia = 0
            ecpn = 0
            ecpa = 0
            lcipd = 0
            lcicm = 0
            lcith = 0
            lciot = 0
            lcppd = 0
            lcpga = 0
            lcpcl = 0
            lcpcj = 0
            lcpz = 0
            lcpot = 0
        }
        const datos = {
            casa,
            inicio, final, ecin, ecia, ecpn, ecpa, lcipd, lcicm, lcith, lciot, lcppd,comunidad, municipio,
            lcpga, lcpcl, lcpcj, lcpz, lcpot, usuario1, fecha: fecha_.split(' ')[0], usuario: user, prerociado, disponible,
        }
        if ((ecin + ecia) != (lcipd + lcicm + lcith + lciot)) {
            return res.json({ ok: false, msg: 'Debe coincidir la sumatoia de Los ejemplares capturados en el interior del domicilio ' })

        }
        if ((ecpn + ecpa) != (lcppd + lcpga + lcpcl + lcpcj + lcpz + lcpot)) {
            return res.json({ ok: false, msg: 'Debe coincidir la sumatoia de Los ejemplares capturados en el PERI/Exterior del domicilio ' })
        }
        const resultado = await ee1.insertar(datos, comunidad)
        if (resultado === -1) {
            return res.json({ ok: false, msg: 'Esta vivienda no esta registrada' })
        }
        if (resultado === -2) {
            return res.json({ ok: false, msg: 'Ya existe un registro con este CV para hoy "sin fecha de emision", espere a la nueva orden de su jefe de brigada' })
        }
        if (resultado === -3) {
            return res.json({ ok: false, msg: 'Otro colega suyo ya empezo con la evaluacion entomologica de esta comunidad, Le sujerimos cambiar a otra comunidad, o comuniquese con su jefe de brigada. ' })
        }

        if (!resultado) {
            return res.json({ ok: false, msg: 'No se ha podido guardar el registro, intentelo nuvamente..!!!' })
        }
        return res.json({ ok: true, msg: 'Registro Guardado' })

    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})



rutas.post("/actualizar", editar, async (req, res) => {
    try {
        let { id,
            casa,comunidad,
            inicio, final, ecin, ecia, ecpn, ecpa, lcipd, lcicm, lcith, lciot, lcppd,
            lcpga, lcpcl, lcpcj, lcpz, lcpot, usuario1, prerociado,disponible,
            fecha_ } = req.body
        if (!disponible) {
            ecin = 0
            ecia = 0
            ecpn = 0
            ecpa = 0
            lcipd = 0
            lcicm = 0
            lcith = 0
            lciot = 0
            lcppd = 0
            lcpga = 0
            lcpcl = 0
            lcpcj = 0
            lcpz = 0
            lcpot = 0
        }
        const datos = {
            id,
            casa,comunidad,
            inicio, final, ecin, ecia, ecpn, ecpa, lcipd, lcicm, lcith, lciot, lcppd,
            lcpga, lcpcl, lcpcj, lcpz, lcpot, usuario1, fecha: fecha_.split(' ')[0], prerociado,disponible
        }
        if ((ecin + ecia) != (lcipd + lcicm + lcith + lciot)) {
            return res.json({ ok: false, msg: 'Debe coincidir la sumatoia de Los ejemplares capturados en el interior del domicilio ' })

        }
        if ((ecpn + ecpa) != (lcppd + lcpga + lcpcl + lcpcj + lcpz + lcpot)) {
            return res.json({ ok: false, msg: 'Debe coincidir la sumatoia de Los ejemplares capturados en el PERI/Exterior del domicilio ' })
        }
        const resultado = await ee1.actualizar(datos)

        if (resultado === -1) {
            return res.json({ ok: false, msg: 'Numero control vectorial ya esta registrada' })
        }

        if (!resultado) {
            return res.json({ msg: 'Actualizacion Fállida', ok: false })
        }
        return res.json({ ok: true, msg: 'Registro actualizado' })

    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})



rutas.post("/eliminar", eliminar, async (req, res) => {
    try {
        const id = req.body.id;
        const resultado = await ee1.eliminar(id)
        if (!resultado) {
            return res.json({ msg: 'Ops! No se ha eliminado el registro.', ok: false })
        }
        return res.json({ ok: true, msg: 'Registro eliminado correctamete' })

    } catch (error) {
        console.log(error)
        return res.json({ error: 500, msg: error.sqlMessage + '. Puede existir valores dependientes a este registro. COnsulte con el administrador' });
    }
})

rutas.post("/validar", completar, async (req, res) => {  
    try {
        const fecha = req.body.fecha_;
        const usuario = req.body.user;
        const comunidad = req.body.comunidad;
        const resultado = await ee1.validar(fecha, usuario, comunidad)
        if (!resultado) {
            return res.json({ msg: 'Ops! No se ha podido completar la accion!. No existen registros para enviar/', ok: false })
        }
        if (resultado === -1) {
            return res.json({ msg: 'Para realizar el envio de informacion primero debe completar con la actividad hasta terminar con la ultima vivienda de esta comunidad, verifique si tiene registros para enviar', ok: false })
        }

        if (resultado === -2) {
            return res.json({ msg: 'La cobertura almenos deveria alcanzar el 70%', ok: false })
        }
        return res.json({ ok: true, msg: 'El registro se ha enviado correctamete' })

    } catch (error) {
        console.log(error)
        return res.json({ error: 500, msg: error.sqlMessage });
    }
})


module.exports = rutas;