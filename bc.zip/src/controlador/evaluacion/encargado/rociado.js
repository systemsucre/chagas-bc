const { Router } = require("express")
const Rociado = require("../../../modelo/evaluacion/encargado/rociado.js")
const { buscar , id} = require("../../../validacion/evaluacion/encargado/rociado.js") 


const rutas = Router()
const rociado = new Rociado()

rutas.post("/listar", async (req, res) => {
    try {
        const resultado = await rociado.listar(req.body.municipio_id_tec)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})

rutas.post("/ver-avance", async (req, res) => {
    try {
        const resultado = await rociado.mostrarAvance(req.body.municipio_id_tec)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})

rutas.post("/buscar", buscar, async (req, res) => {
    try {
        const resultado = await rociado.buscar(req.body.fecha1, req.body.fecha2, req.body.municipio_id_tec)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage }); 
    }
})
rutas.post("/habilitar-edicion", async (req, res) => {
    try {
        const resultado = await rociado.habilitarEdicion(req.body.codigo)
        if(!resultado) return res.json({ok:false, msg:'El servidor no ha podido completar la transaccion.!'})
        return res.json({ ok: true, msg:'Edicion habilitada exitosamente.' })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage }); 
    }
})

rutas.post("/validar-informacion", async (req, res) => {
    try {
        const resultado = await rociado.validar( req.body.fecha_,  req.body.codigo) 
        if(!resultado) return res.json({ok:false, msg:'El servidor no ha podido completar la transaccion.!'})
        return res.json({ ok: true, msg:'La informacion se ha enviado al nivel departamental exitosamente.' })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage }); 
    }
})

rutas.post("/listar-por-comunidad", async (req, res) => {
    try {
        const resultado = await rociado.listarPorComunidad(req.body.codigo) 
        return res.json({ data:resultado,  ok: true, msg:'La informacion se ha enviado al nivel departamental exitosamente.' })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage }); 
    }
})




module.exports = rutas;