const { Router } = require("express")
const EE2 = require("../../../modelo/evaluacion/encargado/ee2.js")
const { buscar , id} = require("../../../validacion/evaluacion/encargado/ee2.js") 


const rutas = Router()
const ee2 = new EE2()

rutas.post("/listar", async (req, res) => {
    try {
        const resultado = await ee2.listar(req.body.municipio_id_tec)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})

rutas.post("/ver-avance", async (req, res) => {
    try {
        const resultado = await ee2.mostrarAvance(req.body.municipio_id_tec)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage });
    }
})

rutas.post("/buscar", buscar, async (req, res) => {
    try {
        const resultado = await ee2.buscar(req.body.fecha1, req.body.fecha2, req.body.municipio_id_tec)
        return res.json({ data: resultado, ok: true })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage }); 
    }
})
rutas.post("/habilitar-edicion", id, async (req, res) => {
    try {
        const resultado = await ee2.habilitarEdicion(req.body.id)
        if(!resultado) return res.json({ok:false, msg:'El servidor no ha podido completar la transaccion.!'})
        return res.json({ ok: true, msg:'Edicion habilitada exitosamente.' })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage }); 
    }
})

rutas.post("/validar-informacion", async (req, res) => {
    try {
        const resultado = await ee2.validar(req.body.municipio_id_tec, req.body.fecha_, req.body.user) 
        if(!resultado) return res.json({ok:false, msg:'El servidor no ha podido completar la transaccion.!'})
        return res.json({ ok: true, msg:'La informacion se ha enviado al nivel departamental exitosamente.' })
    } catch (error) {
        console.log(error)
        return res.json({ ok: false, msg: error.sqlMessage }); 
    }
})



module.exports = rutas;