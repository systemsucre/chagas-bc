const express = require("express")
const pool = require("../modelo/bdConfig.js")
const { KEY, CLAVEGMAIL } = require("../config.js")

const jwt = require("jsonwebtoken")

const {
  getTime,
  getDate,
} = require("util-tiempo")




const miPerfil = require("../controlador/miPerfil.js");

// Admiministrador

const casa = require("../controlador/admin/casa.js")
const comunidad = require("../controlador/admin/comunidad.js")
const entidad = require("../controlador/admin/entidad.js")
const usuario = require("../controlador/admin/usuario.js")

//TECNICO
const evaluacion1 = require("../controlador/evaluacion/tecnico/ee1.js")
const evaluacion2 = require("../controlador/evaluacion/tecnico/ee-2.js")
const rociado1 = require("../controlador/evaluacion/tecnico/rociado.js")

// JEFE DE BRIGADA
const EE2_Encargado = require("../controlador/evaluacion/encargado/ee-2.js")
const RR2_Rociado = require("../controlador/evaluacion/encargado/rociado.js")



//PUBLICOS
const home = require("../controlador/Public/public.js")


// import { createOrder, recivedWebhook } from "../controlador/controller/payment.controller.js";



const rutas = express();

// +*********************************************************** login****************************************

// ruta de autentidicacion
rutas.get("/", async (req, res) => {
  try {
    const sql = `SELECT 
          u.id, u.correo,u.celular,u.usuario,
          u.nombre,u.ap1, 
          
          h.id as hospital, h.nombre as hospital_des,
          m.id as municipio, m.nombre as municipio_des,
          r.id as red, r.nombre as red_des,
          UPPER(ro.rol) as rol_des, ro.id as rol, 

          mu.id as idmunicipio_tec, mu.nombre as municipio_tec

          from usuario u 
          left join municipio mu on mu.id = u.municipio
          left join hospital h on h.id = u.hospital
          left join municipio m on m.id = h.municipio
          left join red r on r.id = m.red
          left join rol ro on u.rol = ro.id
          where u.usuario = ${pool.escape(req.query.intel)} and u.contraseña = ${pool.escape(req.query.viva)} and u.estado = true`;
    const [result] = await pool.query(sql);
    console.log(result, 'iniciio de sesion', req.query.intel, req.query.viva)
    if (result.length === 1) {
      const payload = {
        municipio: result[0].municipio_des,
        name: result[0].nombre + result[0].ap1,
        hospital: result[0].hospital_des,
        fecha: new Date(),
      };
      const token = jwt.sign(payload, KEY, {
        expiresIn: "1d",
      });

      let fecha = getDate({ timeZone: "America/La_Paz", })
      const datos = {
        usuario: result[0].id,
        usuario_des: result[0].usuario,
        rol: result[0].rol,
        rol_des: result[0].rol_des,

        nombre: result[0].nombre + ' ' + result[0].ap1,
        token,
        fecha: fecha.split('/')[2] + '-' + fecha.split('/')[1] + '-' + fecha.split('/')[0],
        hora: getTime({ timezone: "America/La_Paz" }),

        hospital: result[0].hospital,
        hospital_des: result[0].hospital_des,
        red: result[0].red,
        red_des: result[0].red_des,
        municipio: result[0].municipio,
        municipio_des: result[0].municipio_des,
        municipio_tec: result[0].municipio_tec,
        municipio_id_tec: result[0].idmunicipio_tec,

      };

      const [sesion] = await pool.query(`INSERT INTO sesion SET ?`, datos);
      // console.log('dentro del bloque', sesion)

      if (sesion.insertId > 0) {
        return res.json({
          token: token,
          username: result[0].usuario,
          nombre: result[0].nombre + ' ' + result[0].ap1,
          celular: result[0].celular,
          correo: result[0].correo,
          rol_des: result[0].rol_des,
          rol: result[0].rol,

          hospital_des: result[0].hospital_des,
          red_des: result[0].red_des,
          municipio_des: result[0].municipio_des,

          municipio_des: result[0].municipio_tec,
          ok: true,
          msg: "Acceso correcto",
        });
      } else {
        return res.json({ msg: "Intente nuevamente ", ok: false });
      }
    } else {
      return res.json({ msg: "El usuario no existe !", ok: false });
    }
  } catch (error) {
    console.log(error);
    return res.json({ msg: "El servidor no responde !", ok: false });
  }
});

rutas.post("/logout", (req, res) => {
  try {
    // console.log(req.body);
    if (req.body.token) {
      const sql = `delete from sesion where token = ${pool.escape(
        req.body.token
      )} `;
      pool.query(sql);
    }
  } catch (error) { }
});


//VERIFICACION DE LA SESION QUE ESTA ALMACENADA EN LA BD
const verificacion = express();

verificacion.use((req, res, next) => {
  try {

    let fecha = getDate({ timeZone: "America/La_Paz", })
    let formato = fecha.split('/')[2] + '-' + fecha.split('/')[1] + '-' + fecha.split('/')[0] + ' ' + getTime({ timezone: "America/La_Paz" })
    // console.log(formato, ' hora peru')
    const bearerHeader = req.headers["authorization"];

    if (typeof bearerHeader !== "undefined") {
      const bearetoken = bearerHeader.split(" ")[1];
      // console.log('pasa la primera condicional, se ha obtenido los encabezados', bearetoken )

      jwt.verify(bearetoken, KEY, async (errtoken, authData) => {
        if (errtoken) {
          console.log('error en la verificacion token alterado: ', bearetoken)
          pool.query("delete from sesion where token = ?", [bearetoken]);
          return res.json({
            ok: false,
            sesion: false,
            msg: "Su token a expirado, cierre sesion y vuelva a iniciar sesion",
          });
        }

        const sql = `SELECT usuario, usuario_des, rol,  nombre,   hospital_des, hospital, municipio_tec, municipio_id_tec  from sesion s 
                  where token  = ${pool.escape(bearetoken)}`;
        const [result] = await pool.query(sql);
        // console.log('pasa la verificacion del token', result[0].idusuario)

        if (result.length > 0) {
          req.body.user = await result[0].usuario;
          req.body.usernameS = await result[0].usuario_des;
          req.body.srol = await result[0].rol;
          req.body.shospital = await result[0].hospital_des;
          req.body.sidhospital = await result[0].hospital;
          req.body.sidmunicpio = await result[0].municipio;
          req.body.municipio_tec = await result[0].municipio_tec;
          req.body.municipio_id_tec = await result[0].municipio_id_tec;
          req.body.nombreusuarioS = await result[0].nombre;
          req.body.fecha_ = formato;
          next();
        } else {
          return res.json({
            ok: false,
            sesion: false,
            msg: "El Servidor no puede identificar su autencidad, cierre sesion y vuelva a intentar",
          });
        }
      });
    } else {
      return res.json({
        ok: false,
        sesion: false,
        msg: "El Servidor no puede interpretar su autenticidad",
      });
    }
  } catch (error) {
    console.log(error);
    return res.json({ ok: false, sesion: false, msg: "Error en el servidor" });
  }
});

const admin = (req, res, next) => {
  if (parseInt(req.body.srol) === 1) {
    // console.log(req.body.numero, 'numero rol')
    next();
  } else
    return res.json({
      ok: false,
      sesion: false,
      msg: "El Servidor no puede identificar su autencidad, cierre sesion y vuelva a intentar",
    });
};

const tecnico = (req, res, next) => {
  if (parseInt(req.body.srol) === 3) {
    next();

  } else
    return res.json({
      ok: false,
      sesion: false,
      msg: "El Servidor no puede identificar su autencidad, cierre sesion y vuelva a intentar",
    });
};

const encargado = (req, res, next) => {
  if (parseInt(req.body.srol) === 2) {
    next();

  } else
    return res.json({
      ok: false,
      sesion: false,
      msg: "El Servidor no puede identificar su autencidad, cierre sesion y vuelva a intentar",
    });
};

const funcionesCompartidos = (req, res, next) => {
  if (parseInt(req.body.srol) === 1 || parseInt(req.body.srol) === 2|| parseInt(req.body.srol) === 3) {
    next();

  } else
    return res.json({
      ok: false,
      sesion: false,
      msg: "El Servidor no puede identificar su autencidad, cierre sesion y vuelva a intentar",
    });
};




// ADMINISTRADOR

rutas.use("/comunidad", verificacion, admin, comunidad);
rutas.use("/hospital", verificacion, admin, entidad);
rutas.use("/usuarios", verificacion, admin, usuario);




// JEFE DE BRIGADA MUNICIPAL

rutas.use("/ee-2-encargado", verificacion, encargado, EE2_Encargado);
rutas.use("/rr-2", verificacion, encargado, RR2_Rociado);



// tecnico operativo
rutas.use("/ee-1", verificacion, tecnico, evaluacion1);
rutas.use("/ee-2", verificacion, tecnico, evaluacion2);
rutas.use("/rociado-1", verificacion, tecnico, rociado1);



rutas.use("/casa", verificacion, funcionesCompartidos, casa);



rutas.use("/miPerfil", verificacion, miPerfil);
rutas.use(home);


module.exports = rutas
