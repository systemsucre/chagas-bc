
const { validationResult } = require("express-validator")
const validaciones = (req, res, next) => {

    try {
        const error = validationResult(req)

        if (!error.isEmpty()) {
            // console.log(error)
            console.log(req.body, 'MIS DATOS BUSQUEDA')

            return res.json({ msg: 'Campo [' + error.errors[0].param + '] inválido !,  verifique que este dato.', ok: false })
        }
        return next()
    }
    catch (error) {
        return res.json({ msg: "Error intentelo mas tarde !", ok: false })
    }
}
module.exports = { validaciones }