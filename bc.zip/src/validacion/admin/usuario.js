const  {check} = require("express-validator")
const { validaciones }  = require("../headers.js")

const insertar = [
  check("cantidad").isLength({ min: 1 }).exists().isNumeric(),

  check("ci")
    .matches(/^\d{5,15}((\s|[-])\d{1}[A-Z]{1})?$/)
    .exists(),
  check("nombre")
    .matches(/^.{4,3000}$/)
    .exists(),
  check("celular")
    .matches(/^\d{1,10}$/)
    .exists(),
  check("correo").matches(/^\w+([.-_+]?\w+)*@\w+([.-]?\w+)*(\.\w{2,10})+$/),
  check("especialidad").isLength({ min: 1 }).exists().isNumeric(),
  check("rol_").isLength({ min: 1 }).exists().isNumeric(),
  check("entidad").isLength({ min: 1 }).exists().isNumeric(),
  check("contraseña")
    .matches(/^.{1,1500}$/s)
    .exists(),

  (req, res, next) => {
    validaciones(req, res, next);
  },
];

const actualizar = [
  check("id")
    .matches(/^\d{1,10}$/)
    .exists(),
  check("ci")
    .matches(/^\d{5,15}((\s|[-])\d{1}[A-Z]{1})?$/)
    .exists(),
  check("nombre")
    .matches(/^.{4,3000}$/)
    .exists(),
  check("celular")
    .matches(/^\d{1,10}$/)
    .exists(),
  check("correo").matches(/^\w+([.-_+]?\w+)*@\w+([.-]?\w+)*(\.\w{2,10})+$/),
  check("especialidad").isLength({ min: 1 }).exists().isNumeric(),
  check("rol_").isLength({ min: 1 }).exists().isNumeric(),
  check("entidad").isLength({ min: 1 }).exists().isNumeric(),
  check("cantidad").isLength({ min: 1 }).exists().isNumeric(),

  (req, res, next) => {
    validaciones(req, res, next);
  },
];

const recet = [
  check("id")
    .matches(/^\d{1,10}$/)
    .exists(),
  check("otros")
    .matches(/^.{4,3000}$/)
    .exists(),

  (req, res, next) => {
    validaciones(req, res, next);
  },
];

const actualizarMiPerfil = [

  check("nombre")
    .matches(/^[a-zA-ZÑñ ]{2,50}$/)
    .exists(),
  check("apellido_paterno")
    .matches(/^[a-zA-ZÑñ ]{2,50}$/)
    .exists(),
  check("apellido_materno")
    .matches(/^[a-zA-ZÑñ ]{2,50}$/)
    .exists()
    .optional(),
  check("celular")
    .matches(/^\d{1,10}$/)
    .exists(),
    check("direccion")
    .matches(/^[a-zA-ZÑñ /0-9-@.,+]{1,100}$/)
    .exists(),
  check("correo").matches(/^\w+([.-_+]?\w+)*@\w+([.-]?\w+)*(\.\w{2,10})+$/),

  (req, res, next) => {
    validaciones(req, res, next);
  },
];

const cambiarMiContraseña = [
  check("contraseña_actual").exists().isLength({ min: 5 }),
  check("nueva_contraseña").exists().isLength({ min: 5 }),
  (req, res, next) => {
    validaciones(req, res, next);
  },
];

const buscar = [
  check("dato")
    .matches(/^[()/a-zA-Z.@ Ññ0-9_-]{1,400}$/)
    .exists(),
  (req, res, next) => {
    validaciones(req, res, next);
  },
];

const siguiente = [
  check("cantidad").isLength({ min: 1 }).exists().isNumeric(),
  check("id").isLength({ min: 1 }).exists().isNumeric(),

  (req, res, next) => {
    validaciones(req, res, next);
  },
];

const anterior = [
  check("cantidad").isLength({ min: 1 }).exists().isNumeric(),
  check("id").isLength({ min: 1 }).exists().isNumeric(),

  (req, res, next) => {
    validaciones(req, res, next);
  },
];

module.exports ={insertar, actualizar, recet, actualizarMiPerfil, cambiarMiContraseña, buscar,
  siguiente, anterior
}
